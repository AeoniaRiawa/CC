function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(220);
  
  // Body
  fill(100, 50, 40);
  rect(50, 100, 300, 50);
  rect(100, 50, 200, 50);
  
  // Cabin
  fill(20, 40, 25);
  rect(100, 50, 100, 50);
  
  // Windows
  fill(200);
  rect(110, 60, 40, 30);
  
  // Wheels
  fill(0);
  ellipse(125, 150, 40, 40);
  ellipse(275, 150, 40, 40);
  
  // Wheel arcs
  noFill();
  stroke(0);
  strokeWeight(2);
  arc(125, 150, 50, 50, 0, PI + QUARTER_PI);
  arc(275, 150, 50, 50, 0, PI + QUARTER_PI);
}