let data = [19, 20, 21, 22, 23]; // Sample data of ages
let barWidth;
let maxData;
let scaleFactor = 0.7; // Adjust this value to make the bars shorter or taller

function setup() {
  createCanvas(300, 300); // Smaller canvas size
  barWidth = width / data.length / 2; // Reducing the bar width
  maxData = max(data);
}

function draw() {
  background(220);
  
  // Draw bars
  for (let i = 0; i < data.length; i++) {
    let x = i * barWidth * 2; // Adjusted x position
    let barHeight = map(data[i], 0, maxData, 0, height); // Adjusted y position
    barHeight *= scaleFactor; // Adjusting the bar height
    let y = height - barHeight; // Adjusted y position to start from the bottom
    let randomColor = color(random(255), random(255), random(255)); // Generate random color
    fill(randomColor);
    rect(x, y, barWidth, barHeight); // Adjusted bar width
    
    // Display age labels
    textAlign(CENTER);
    fill(0);
    text(data[i], x + barWidth / 2, y - 10);
  }
  
  // Title
  textAlign(CENTER);
  textSize(18); // Adjusted title size
  fill(0);
  text("Average Age of College Students", width / 2, 20); // Adjusted title position
}