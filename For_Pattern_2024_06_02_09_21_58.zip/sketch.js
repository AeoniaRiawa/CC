function setup() {
  createCanvas(400, 400);
  generateRandomPattern();
}

function generateRandomPattern() {
  background(0);
  
  // Define parameters
  let numShapes = 100; // Number of shapes
  let maxSize = 100; // Maximum size of shapes
  
  // Draw random shapes using a loop
  for (let i = 0; i < numShapes; i++) {
    // Generate random position and size for each shape
    let x = random(width);
    let y = random(height);
    let size = random(10, maxSize);
    
    // Generate random color for each shape
    let r = random(200);
    let g = random(200);
    let b = random(200);
    
    // Randomly select shape type
    let shapeType = int(random(3)); // 0: Circle, 1: Triangle, 2: Square
    
    // Set fill color
    fill(r, g, b);
    
    // Draw shapes
    if (shapeType === 0) {
      ellipse(x, y, size, size); // Circle
    } else if (shapeType === 1) {
      triangle(x, y - size / 2, x - size / 2, y + size / 2, x + size / 2, y + size / 2); // Triangle
    } else if (shapeType === 2) {
      rect(x - size / 2, y - size / 2, size, size); // Square
    }
  }
}