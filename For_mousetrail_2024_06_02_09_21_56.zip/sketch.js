let triangles = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  noCursor(); // Hide the default mouse cursor
}

function draw() {
  background(255); // Clear the background each frame
  
  // Generate multiple triangles per frame
  for (let j = 0; j < 5; j++) {
    // Add a new triangle at the mouse position
    let t = {
      x1: mouseX, 
      y1: mouseY, 
      x2: mouseX + random(-10, 10), 
      y2: mouseY + random(-10, 10), 
      x3: mouseX + random(-10, 10), 
      y3: mouseY + random(-10, 10), 
      alpha: 255
    };
    triangles.push(t);
  }
  
  // Draw and fade out the triangles
  for (let i = triangles.length - 1; i >= 0; i--) {
    let tri = triangles[i];
    fill(255, 105, 180, tri.alpha); // Pink color (RGB: 255, 105, 180) with fading alpha
    noStroke();
    triangle(tri.x1, tri.y1, tri.x2, tri.y2, tri.x3, tri.y3);
    tri.alpha -= 5; // Decrease the alpha value
    
    // Remove the triangle from the array if it is fully transparent
    if (tri.alpha <= 0) {
      triangles.splice(i, 1);
    }
  }
}