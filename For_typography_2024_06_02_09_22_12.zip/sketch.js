var word = "LETTERS WOW!";

var font1, font2, font3;

function preload() {
  font1 = loadFont("BlackOpsOne-Regular.ttf");
  font2 = loadFont("Comfortaa-Light.ttf");
  font3 = loadFont("ShadowsIntoLight.ttf");
}

function setup() {
  createCanvas(600, 400);
  background(255);
  fill(0);

  // Using the first font
  textFont(font1, 50);
  textAlign(CENTER, CENTER);
  text(word, width / 2, height / 3);

  // Using the second font
  textFont(font2, 30);
  textAlign(LEFT, CENTER);
  text(word, 10, height / 2);

  // Using the third font
  textFont(font3, 40);
  textAlign(RIGHT, CENTER);
  text(word, width - 10, 2 * height / 3);

  // Mix the fonts in one line
  textAlign(CENTER, CENTER);
  for (let i = 0; i < word.length; i++) {
    let char = word.charAt(i);
    if (i % 3 == 0) {
      textFont(font1);
    } else if (i % 3 == 1) {
      textFont(font2);
    } else {
      textFont(font3);
    }
    text(char, width / 2 - 120 + i * 24, height - 50);
  }
}