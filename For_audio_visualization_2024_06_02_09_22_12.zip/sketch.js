let mic;
let fft;
let numPoints = 256; // Number of points on the sphere

function setup() {
  createCanvas(400, 400, WEBGL);
  colorMode(HSB, 360, 100, 100); // Set color mode to HSB
  
  // Create an audio input and FFT (Fast Fourier Transform) object
  mic = new p5.AudioIn();
  mic.start();
  fft = new p5.FFT();
  fft.setInput(mic);
}

function draw() {
  background(0);
  
  // Analyze the sound spectrum
  let spectrum = fft.analyze(numPoints);
  
  // Rotate the scene for better visualization
  rotateY(frameCount * 0.01);
  rotateX(frameCount * 0.01);
  
  // Draw the sphere
  beginShape();
  for (let i = 0; i < numPoints; i++) {
    let angle = map(i, 0, numPoints, 0, TWO_PI);
    let radius = map(spectrum[i], 0, 255, 50, 200); // Adjust radius based on spectrum
    let x = radius * cos(angle);
    let y = radius * sin(angle);
    let z = 0; // Keep z-coordinate zero for 2D representation
    let hue = map(i, 0, numPoints, 0, 360); // Map hue based on position
    fill(hue, 100, 100); // Set fill color based on hue
    noStroke();
    vertex(x, y, z);
  }
  endShape(CLOSE);
}