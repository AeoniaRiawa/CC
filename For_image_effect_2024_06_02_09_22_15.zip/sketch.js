let img;
let maskGraphics;

function preload() {
  img = loadImage('Himaribells.jpg'); // Load the image
}

function setup() {
  createCanvas(400, 400);
  
  // Scale the image to fit within the canvas
  img.resize(width, height);
  
  maskGraphics = createGraphics(width, height);
  
  // Create a mask
  maskGraphics.beginShape();
  maskGraphics.vertex(width / 2, 0);          // Top vertex
  maskGraphics.vertex(width, height);         // Bottom right vertex
  maskGraphics.vertex(0, height);             // Bottom left vertex
  maskGraphics.endShape(CLOSE);
  
  // Apply the mask to the image
  img.mask(maskGraphics);
}

function draw() {
  background(0); // Black background
  image(img, 0, 0); // Display the masked image
  
  // Set text properties
  fill(0); // Black color
  textSize(32);
  textAlign(CENTER, CENTER);
  
  // Position the text inside the triangle
  text("Chibi", width / 2, height / 2);
}