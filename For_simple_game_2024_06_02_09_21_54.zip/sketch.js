let circles = [];
let score = 0;
let offScreenCount = 0;
let gameOver = false;
let titleClicked = false;
let trail = [];

function setup() {
  createCanvas(400, 400);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(220);

  if (!gameOver) {
    if (!titleClicked) {
      // Title screen
      textSize(32);
      fill(0);
      text("SNAKE!", width / 2, height / 2);
      textSize(18);
      text("Click to Start", width / 2, height / 2 + 40);
    } else {
      // Display score
      textSize(24);
      text("Score: " + score, width / 2, 30);

      // Update and display circles
      for (let i = circles.length - 1; i >= 0; i--) {
        circles[i].update();
        circles[i].display();

        // Check if the circle is clicked
        if (circles[i].isClicked()) {
          score++;
          circles.splice(i, 1);
        } else if (circles[i].y + circles[i].radius < 0) { // Check if the circle goes off the screen
          offScreenCount++;
          circles.splice(i, 1);
        }
      }

      // Check if the player loses
      if (offScreenCount >= 5 || score >= 150) {
        gameOver = true;
        textSize(32);
        if (score >= 150) {
          fill(0, 255, 0); // Change color for win message
          text("You Win!", width / 2, height / 2);
        } else {
          fill(255, 0, 0);
          text("Game Over", width / 2, height / 2);
        }
        text("Click to play again", width / 2, height / 2 + 40);
        noLoop(); // Stop the game loop
      }

      // Add a new circle randomly
      if (frameCount % 30 == 0 && offScreenCount < 5) { // Change this to control circle spawn rate and check if the player hasn't lost
        let newCircle = new Circle(random(width), height); // Start from the bottom
        circles.push(newCircle);
      }
    }
  }
  
  // Draw mouse trail
  for (let i = 0; i < trail.length; i++) {
    fill(0, 0, 255, 100); // Blue with transparency
    noStroke();
    ellipse(trail[i].x, trail[i].y, 10, 10); // Adjust size as needed
  }
}

// Circle class
class Circle {
  constructor(x, y, special = false) {
    this.x = x;
    this.y = y;
    this.radius = 30;
    if (special) {
      this.color = color(0); // Black color for special circle
    } else {
      this.color = color(random(255), random(255), random(255));
    }
    this.speed = random(5, 10); // Increase speed range for faster movement
  }

  update() {
    // Move the circle upwards
    this.y -= this.speed;
  }

  display() {
    fill(this.color);
    ellipse(this.x, this.y, this.radius * 2);
  }

  // Check if the circle is clicked
  isClicked() {
    let d = dist(this.x, this.y, mouseX, mouseY);
    return (d < this.radius);
  }
}

// Mouse click event
function mousePressed() {
  if (!gameOver) {
    titleClicked = true;
  } else {
    // Reset the game if it's over
    circles = [];
    score = 0;
    offScreenCount = 0;
    gameOver = false;
    titleClicked = false;
    loop(); // Restart the game loop
  }
}

// Mouse movement event to track mouse position for the trail
function mouseMoved() {
  trail.push({x: mouseX, y: mouseY});
  
  // Limit the number of points in the trail
  if (trail.length > 50) {
    trail.splice(0, 1);
  }
}