function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0, 0, 0); // Black background
  
  // Head
  fill(150, 255, 150); // Green color for head
  ellipse(200, 200, 150, 150); // Head
  
  // Eyes
  fill(255); // White color for eyes
  ellipse(170, 180, 30, 30); // Left eye
  ellipse(230, 180, 30, 30); // Right eye
  
  // Pupils
  fill(100,150,250); // blue color for pupils
  ellipse(170, 180, 10, 10); // Left pupil
  ellipse(230, 180, 10, 10); // Right pupil
  
  // Mouth
  stroke(0); // Black color for stroke
  strokeWeight(3); // Thicker stroke
  noFill(); // No fill for mouth
  arc(200, 220, 100, 20, 0, PI); // Smile
}