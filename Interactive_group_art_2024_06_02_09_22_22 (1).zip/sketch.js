let orbs = [];
let orbTrailLength = 10;
let maxOrbs = 100;
let followingText = "BLACK HOLE";
let avoidMouse = true; // Default to Avoid Mouse
let rotationAngle = 0; // Default Rotation Angle (for the BlackHole)

function setup() {
  createCanvas(700, 700);
  for (let i = 0; i < maxOrbs; i++) {
    orbs.push(new Orb());
  }
}

function draw() {
  background(0);
  for (let i = 0; i < orbs.length; i++) {
    let orb = orbs[i];
    orb.update();
    orb.display();
  }

  // Update rotation angle
  rotationAngle += 0.05; // Adjust rotation speed as needed

  // Display following text with rotation
  push();
  translate(mouseX, mouseY);
  rotate(rotationAngle);
  textAlign(CENTER, CENTER);
  fill(255);
  textSize(20);
  text(followingText, 0, 0);
  pop();

  // Foreground:
  noStroke();
  mask = createGraphics(width, height);
  mask.fill(38, 34, 87, 200);
  mask.rect(0, 0, 700, 700); // x , y, width and height
  mask.erase();
  mask.textSize(100);
  mask.textFont("Fantasy");
  mask.rotate(100); // Rotate the canvas by the specified angle
  
  // Clipping
  push();
  clip(
    () => {
      for (i=0;i<10;i++) {
      mask.text("WELCOME TO BATH SPA UNIVERSITY", -150*i, 100*i);
      }
      mask.rotate(-100);
      mask.circle(mouseX, mouseY, 200); // Draw a circle for clipping
      image(mask, 0, 0); // Draw the clipped shape
    },
    { invert: true }
  );
  pop();
}

class Orb {
  constructor() {
    this.position = createVector(random(width), random(height));
    this.velocity = p5.Vector.random2D();
    this.velocity.setMag(random(1, 3));
    this.color = color(random(255), random(255), random(255), 150);
    this.prevPositions = [];
  }

  update() {
    // Store previous positions
    this.prevPositions.push(this.position.copy());
    if (this.prevPositions.length > orbTrailLength) {
      this.prevPositions.splice(0, 1);
    }

    // Apply resistance
    let resistance = this.velocity.copy().mult(-0.01); // Adjust the resistance factor
    this.velocity.add(resistance);

    // Move the orb
    if (avoidMouse) {
      // Avoid mouse
      let mouse = createVector(mouseX, mouseY);
      let distance = p5.Vector.dist(this.position, mouse);
      if (distance < 100) {
        let avoidForce = p5.Vector.sub(this.position, mouse);
        avoidForce.setMag(1 / distance * 20); // Adjust the strength of avoidance
        this.velocity.add(avoidForce);
      }
    } else {
      // Follow mouse
      let mouse = createVector(mouseX, mouseY);
      let followForce = p5.Vector.sub(mouse, this.position);
      followForce.setMag(0.1); // Adjust the strength of following
      this.velocity.add(followForce);
    }

    // Move the orb
    this.position.add(this.velocity);

    // Wrap around edges
    if (this.position.x < 0) this.position.x = width;
    if (this.position.x > width) this.position.x = 0;
    if (this.position.y < 0) this.position.y = height;
    if (this.position.y > height) this.position.y = 0;
  }

  display() {
    // Draw the orb trail
    noStroke();
    for (let i = 0; i < this.prevPositions.length; i++) {
      let trailColor = color(red(this.color), green(this.color), blue(this.color), map(i, 0, this.prevPositions.length, 0, 255));
      fill(trailColor);
      let trailPos = this.prevPositions[i];
      ellipse(trailPos.x, trailPos.y, 20, 20);
    }

    // Draw the orb
    fill(this.color);
    ellipse(this.position.x, this.position.y, 20, 20);
  }
}

function mouseClicked() {
  avoidMouse = !avoidMouse; // Toggle between avoiding and following the mouse
}